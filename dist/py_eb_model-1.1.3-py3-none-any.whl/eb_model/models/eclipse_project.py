
class Link:
    def __init__(self, name, type, locationURI):
        self.name = name
        self.type = type
        self.locationURI = locationURI

        
