
class TestNvmXdmParser:
    def __init__(self):
        pass
